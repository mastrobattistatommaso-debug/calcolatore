#!/bin/bash
# Avvia l'app in locale sul Mac, così puoi installarla senza metterla online.
cd "$(dirname "$0")"
PORT=8765
echo "Convertitore di unità: avvio su http://localhost:$PORT"
echo "Lascia aperta questa finestra finché non hai installato l'app."
echo "(Per chiudere: premi Ctrl+C)"
( sleep 1; open -a "Google Chrome" "http://localhost:$PORT/index.html" 2>/dev/null || open "http://localhost:$PORT/index.html" ) &
python3 -m http.server $PORT
